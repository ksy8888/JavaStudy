package com.sist.inter;

public interface ChatInterface {
	public void initStyle();
	public void append(String msg, String color);
}
