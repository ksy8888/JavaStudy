package com.sist.inter;

public interface FindInterface {
	public void findPrint(int cno);	//전체보기
	public void findPrint2(String title);	//타이틀에 해당하는거 가져오기
}
