package com.sist.client;
import java.awt.Color;

import javax.swing.JPanel;

public class EnterPanel extends JPanel {
	public EnterPanel() {
		setBackground(Color.magenta);
	}
}
