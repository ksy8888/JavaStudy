package com.sist.client;

import java.awt.Color;

import javax.swing.JPanel;

public class AcommPanel extends JPanel {
	public AcommPanel() {
		setBackground(Color.lightGray);
	}
}
