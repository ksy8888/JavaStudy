package com.sist.client;

import java.awt.Color;

import javax.swing.JPanel;

public class MenuPanel extends JPanel {

	public MenuPanel() {
		//setBackground(Color.yellow);
	}
}
