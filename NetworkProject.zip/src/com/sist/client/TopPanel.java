package com.sist.client;

import java.awt.Color;

import javax.swing.JPanel;

public class TopPanel extends JPanel{
	
	public TopPanel() {
		setBackground(Color.cyan);
	}
}
